The files for the Lab 1 implementation are presented here. 

InitialData.mat contains the slip and initial performance of the vehicle without TCS/ABS controller
SD2231_Lab1 - Simulink file containing the implemnetation. To run Task 5, PID controller block has to be replaced with the inbuilt one commented in the file. 
initial - Initialization file, with all the tuning parameters and plotting results
